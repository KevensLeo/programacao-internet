function calcularSalario() {
  const nivel = document.getElementById('nivel').value;
  const horasSemana = parseFloat(document.getElementById('horas').value);
  const resultado = document.getElementById('resultado');

  if (!nivel || isNaN(horasSemana) || horasSemana <= 0) {
    resultado.style.display = 'block';
    resultado.textContent = 'Por favor, preencha todos os campos corretamente.';
    return;
  }

  let valorHora;

  switch (nivel) {
    case '1':
      valorHora = 12.00;
      break;
    case '2':
      valorHora = 17.00;
      break;
    case '3':
      valorHora = 25.00;
      break;
    default:
      resultado.style.display = 'block';
      resultado.textContent = 'Nível inválido.';
      return;
  }

  const salario = valorHora * horasSemana * 4.5;

  resultado.style.display = 'block';
  resultado.textContent = `Nível: ${nivel} | Horas/semana: ${horasSemana} | Salário mensal: R$ ${salario.toFixed(2)}`;
}
