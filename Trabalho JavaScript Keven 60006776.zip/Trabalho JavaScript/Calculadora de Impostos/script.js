function calcularImposto() {
  const ano = parseInt(document.getElementById("ano").value);
  const valor = parseFloat(document.getElementById("valor").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(ano) || isNaN(valor)) {
    resultado.textContent = "Por favor, preencha todos os campos corretamente.";
    resultado.style.color = "red";
    return;
  }

  let taxa = ano < 1990 ? 0.01 : 0.015;
  let imposto = valor * taxa;

  resultado.textContent = `Imposto a pagar: R$ ${imposto.toFixed(2)}`;
  resultado.style.color = "green";
}
