function calcularCredito() {
  const saldo = parseFloat(document.getElementById('saldo').value);
  const resultado = document.getElementById('resultado');

  if (isNaN(saldo) || saldo < 0) {
    resultado.style.display = 'block';
    resultado.textContent = 'Por favor, insira um saldo médio válido (maior ou igual a zero).';
    return;
  }

  let percentual = 0;

  if (saldo >= 0 && saldo <= 200) {
    percentual = 0;
  } else if (saldo >= 201 && saldo <= 400) {
    percentual = 20;
  } else if (saldo >= 401 && saldo <= 600) {
    percentual = 30;
  } else if (saldo >= 601) {
    percentual = 40;
  }

  const credito = saldo * (percentual / 100);

  resultado.style.display = 'block';

  if (percentual === 0) {
    resultado.textContent = `Saldo médio: R$ ${saldo.toFixed(2)}. Você não tem crédito especial disponível.`;
  } else {
    resultado.textContent = `Saldo médio: R$ ${saldo.toFixed(2)}. Crédito especial concedido: R$ ${credito.toFixed(2)} (${percentual}%).`;
  }
}
