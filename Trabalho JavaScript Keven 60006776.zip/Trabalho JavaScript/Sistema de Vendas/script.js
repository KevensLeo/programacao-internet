function calcularPreco() {
  const preco = parseFloat(document.getElementById('preco').value);
  const codigo = document.getElementById('codigo').value;
  const resultado = document.getElementById('resultado');

  if (isNaN(preco) || preco <= 0 || !codigo) {
    resultado.style.display = 'block';
    resultado.textContent = 'Por favor, preencha todos os campos corretamente.';
    return;
  }

  let final = preco;
  let mensagem = "";

  switch (codigo) {
    case 'a':
      final = preco * 0.90;
      mensagem = "À vista em dinheiro/cheque (10% de desconto)";
      break;
    case 'b':
      final = preco * 0.85;
      mensagem = "À vista no cartão (15% de desconto)";
      break;
    case 'c':
      final = preco;
      mensagem = "Duas vezes sem juros";
      break;
    case 'd':
      final = preco * 1.10;
      mensagem = "Duas vezes com 10% de juros";
      break;
    default:
      resultado.style.display = 'block';
      resultado.textContent = 'Código inválido.';
      return;
  }

  resultado.style.display = 'block';
  resultado.textContent = `Condição: ${mensagem}. Valor a pagar: R$ ${final.toFixed(2)}`;
}
