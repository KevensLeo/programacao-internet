function calcularSalario() {
  const salario = parseFloat(document.getElementById("salario").value);
  const codigo = parseInt(document.getElementById("codigo").value);
  const resultado = document.getElementById("resultado");

  if (isNaN(salario) || isNaN(codigo)) {
    alert("Por favor, preencha todos os campos corretamente.");
    return;
  }

  let percentual = 0;
  let cargo = "";

  switch (codigo) {
    case 101:
      percentual = 10;
      cargo = "Gerente";
      break;
    case 102:
      percentual = 20;
      cargo = "Engenheiro";
      break;
    case 103:
      percentual = 30;
      cargo = "Técnico";
      break;
    default:
      percentual = 40;
      cargo = "Cargo não cadastrado";
  }

  const aumento = salario * (percentual / 100);
  const novoSalario = salario + aumento;

  resultado.style.display = "block";
  resultado.innerHTML = `
    <strong>Cargo:</strong> ${cargo}<br>
    <strong>Salário antigo:</strong> R$ ${salario.toFixed(2)}<br>
    <strong>Percentual de aumento:</strong> ${percentual}%<br>
    <strong>Valor do aumento:</strong> R$ ${aumento.toFixed(2)}<br>
    <strong>Novo salário:</strong> R$ ${novoSalario.toFixed(2)}
  `;
}
