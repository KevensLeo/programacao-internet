function calcularTotal() {
  const codigo = parseInt(document.getElementById('codigo').value);
  const quantidade = parseInt(document.getElementById('quantidade').value);
  const resultado = document.getElementById('resultado');

  const cardapio = {
    100: { nome: "Cachorro-quente", preco: 11.00 },
    101: { nome: "Bauru", preco: 8.50 },
    102: { nome: "Misto-quente", preco: 8.00 },
    103: { nome: "Hambúrguer", preco: 9.00 },
    104: { nome: "Cheeseburger", preco: 10.00 },
    105: { nome: "Refrigerante", preco: 4.50 }
  };

  if (!cardapio[codigo]) {
    resultado.style.display = 'block';
    resultado.textContent = 'Código inválido. Por favor, verifique o cardápio.';
    return;
  }

  if (isNaN(quantidade) || quantidade <= 0) {
    resultado.style.display = 'block';
    resultado.textContent = 'Por favor, digite uma quantidade válida (mínimo 1).';
    return;
  }

  const item = cardapio[codigo];
  const total = item.preco * quantidade;

  resultado.style.display = 'block';
  resultado.textContent = `Produto: ${item.nome} | Quantidade: ${quantidade} | Total: R$ ${total.toFixed(2)}`;
}
