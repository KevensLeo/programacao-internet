document.getElementById("calcularBtn").addEventListener("click", function () {
  const cotacaoInput = document.getElementById("cotacao");
  const resultadoDiv = document.getElementById("resultado");

  const cotacao = parseFloat(cotacaoInput.value);

  if (isNaN(cotacao) || cotacao <= 0) {
    resultadoDiv.innerHTML = "<p>Por favor, insira uma cotação válida.</p>";
    resultadoDiv.style.display = "block";
    return;
  }

  const aumentos = [1, 2, 5, 10];
  let html = `<p>Base: R$ ${cotacao.toFixed(2)}</p><ul>`;

  aumentos.forEach(p => {
    const novoValor = cotacao * (1 + p / 100);
    html += `<li>Com aumento de ${p}%: R$ ${novoValor.toFixed(2)}</li>`;
  });

  html += "</ul>";

  resultadoDiv.innerHTML = html;
  resultadoDiv.style.display = "block";
});
