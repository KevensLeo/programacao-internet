document.getElementById("finalizarBtn").addEventListener("click", function () {
  const sabores = [
    document.getElementById("sabor1").value.trim(),
    document.getElementById("sabor2").value.trim(),
    document.getElementById("sabor3").value.trim(),
    document.getElementById("sabor4").value.trim()
  ];

  const refriQtd = parseInt(document.getElementById("refri").value);
  const resultadoDiv = document.getElementById("resultado");

  if (sabores.some(s => s === "") || isNaN(refriQtd) || refriQtd < 0) {
    resultadoDiv.innerHTML = "<p>Preencha todos os sabores e uma quantidade válida de refrigerantes.</p>";
    resultadoDiv.style.display = "block";
    return;
  }

  const precoPizza = 12.00;
  const precoRefri = 7.00;
  const total = (sabores.length * precoPizza) + (refriQtd * precoRefri);

  resultadoDiv.innerHTML = `
    <p><strong>Sabores escolhidos:</strong></p>
    <ul>
      ${sabores.map(sabor => `<li>${sabor}</li>`).join("")}
    </ul>
    <p><strong>Refrigerantes:</strong> ${refriQtd}</p>
    <p><strong>Total a pagar:</strong> R$ ${total.toFixed(2)}</p>
  `;
  resultadoDiv.style.display = "block";
});
