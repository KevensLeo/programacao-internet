document.getElementById("calcularBtn").addEventListener("click", function () {
  const pessoas = parseInt(document.getElementById("pessoas").value);
  const resultadoDiv = document.getElementById("resultado");

  if (isNaN(pessoas) || pessoas <= 0) {
    resultadoDiv.innerHTML = "<p>Por favor, informe um número válido de pessoas.</p>";
    resultadoDiv.style.display = "block";
    return;
  }

  const ovos = pessoas * 2;
  const queijo = pessoas * 50;

  resultadoDiv.innerHTML = `
    <p>Para ${pessoas} pessoa(s), você vai precisar de:</p>
    <ul>
      <li><strong>${ovos}</strong> ovos</li>
      <li><strong>${queijo}</strong> gramas de queijo</li>
    </ul>
  `;
  resultadoDiv.style.display = "block";
});
