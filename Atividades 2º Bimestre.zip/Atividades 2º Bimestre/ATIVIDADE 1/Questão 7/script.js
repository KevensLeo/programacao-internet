function verificarImpar() {
    const numero = parseInt(document.getElementById('numero').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(numero)) {
        resultado.textContent = "Por favor, digite um número válido.";
        resultado.style.color = "red";
        return;
    }

    if (numero % 2 !== 0) {
        resultado.textContent = `O número ${numero} é ímpar.`;
        resultado.style.color = "green";
    } else {
        resultado.textContent = `O número ${numero} não é ímpar.`;
        resultado.style.color = "blue";
    }
}
