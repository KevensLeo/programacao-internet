function encontrarMenor() {
    const v1 = parseFloat(document.getElementById('v1').value);
    const v2 = parseFloat(document.getElementById('v2').value);
    const v3 = parseFloat(document.getElementById('v3').value);
    const v4 = parseFloat(document.getElementById('v4').value);
    const resultado = document.getElementById('resultado');

    if ([v1, v2, v3, v4].some(isNaN)) {
        resultado.textContent = "Por favor, preencha todos os valores corretamente.";
        resultado.style.color = "red";
        return;
    }

    const menor = Math.min(v1, v2, v3, v4);
    resultado.textContent = `O menor valor é: ${menor}`;
    resultado.style.color = "green";
}
