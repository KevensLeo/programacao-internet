function calcularValorFinal() {
    const valorQuilo = parseFloat(document.getElementById('valorQuilo').value);
    const quantidade = parseFloat(document.getElementById('quantidade').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(valorQuilo) || isNaN(quantidade)) {
        resultado.textContent = "Por favor, insira valores válidos.";
        resultado.style.color = "red";
        return;
    }

    const total = valorQuilo * quantidade;
    resultado.textContent = `Valor a pagar: R$ ${total.toFixed(2)}`;
    resultado.style.color = "green";
}


