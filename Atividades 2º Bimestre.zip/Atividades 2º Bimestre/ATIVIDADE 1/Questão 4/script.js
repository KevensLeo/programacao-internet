function calcularMedias() {
    const n1 = parseFloat(document.getElementById('num1').value);
    const n2 = parseFloat(document.getElementById('num2').value);
    const n3 = parseFloat(document.getElementById('num3').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(n1) || isNaN(n2) || isNaN(n3)) {
        resultado.innerHTML = "<p style='color:red;'>Por favor, preencha todos os campos com números válidos.</p>";
        return;
    }

    const mediaAritmetica = (n1 + n2 + n3) / 3;
    const mediaPonderada = (n1 * 3 + n2 * 2 + n3 * 5) / (3 + 2 + 5);
    const somaMedias = mediaAritmetica + mediaPonderada;
    const mediaDasMedias = somaMedias / 2;

    resultado.innerHTML = `
        <p>Média Aritmética: ${mediaAritmetica.toFixed(2)}</p>
        <p>Média Ponderada: ${mediaPonderada.toFixed(2)}</p>
        <p>Soma das Médias: ${somaMedias.toFixed(2)}</p>
        <p>Média das Médias: ${mediaDasMedias.toFixed(2)}</p>
    `;
}
