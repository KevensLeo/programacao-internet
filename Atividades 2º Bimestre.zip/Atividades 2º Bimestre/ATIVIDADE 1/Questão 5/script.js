function verificarMaior() {
    const valor1 = parseFloat(document.getElementById('valor1').value);
    const valor2 = parseFloat(document.getElementById('valor2').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(valor1) || isNaN(valor2)) {
        resultado.textContent = "Por favor, insira dois valores válidos.";
        resultado.style.color = "red";
        return;
    }

    if (valor1 > valor2) {
        resultado.textContent = `O maior valor é: ${valor1}`;
    } else if (valor2 > valor1) {
        resultado.textContent = `O maior valor é: ${valor2}`;
    } else {
        resultado.textContent = "Os dois valores são iguais.";
    }

    resultado.style.color = "green";
}
