function calcularTroco() {
    const valorPago = parseFloat(document.getElementById('valorPago').value);
    const precoProduto = parseFloat(document.getElementById('precoProduto').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(valorPago) || isNaN(precoProduto)) {
        resultado.textContent = "Por favor, insira valores válidos.";
        resultado.style.color = "red";
        return;
    }

    const troco = valorPago - precoProduto;

    if (troco < 0) {
        resultado.textContent = `Valor insuficiente. Faltam R$ ${Math.abs(troco).toFixed(2)}`;
        resultado.style.color = "red";
    } else {
        resultado.textContent = `Troco: R$ ${troco.toFixed(2)}`;
        resultado.style.color = "green";
    }
}
