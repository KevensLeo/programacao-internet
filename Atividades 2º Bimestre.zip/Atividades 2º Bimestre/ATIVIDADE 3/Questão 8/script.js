function calcularTotal() {
    const PRECO_P = 10;
    const PRECO_M = 12;
    const PRECO_G = 15;
    
    const qtdP = parseInt(document.getElementById('qtdP').value) || 0;
    const qtdM = parseInt(document.getElementById('qtdM').value) || 0;
    const qtdG = parseInt(document.getElementById('qtdG').value) || 0;
    
    if (qtdP < 0 || qtdM < 0 || qtdG < 0) {
        alert("As quantidades não podem ser negativas!");
        return;
    }
    
    const total = (qtdP * PRECO_P) + (qtdM * PRECO_M) + (qtdG * PRECO_G);
    
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        Valor total da venda: 
        <span class="total-destaque">R$ ${total.toFixed(2)}</span>
    `;
    
    resultadoDiv.style.display = 'block';
}