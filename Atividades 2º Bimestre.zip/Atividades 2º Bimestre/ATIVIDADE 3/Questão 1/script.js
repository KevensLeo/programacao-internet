function calcularArea() {
    const comprimento = parseFloat(document.getElementById('comprimento').value);
    const largura = parseFloat(document.getElementById('largura').value);

    if (isNaN(comprimento) || isNaN(largura)) {
        alert("Por favor, digite valores numéricos válidos!");
        return;
    }

    const area = comprimento * largura;

    document.getElementById('resultado').innerHTML = `
        Área do terreno: <strong>${area.toFixed(2)} m²</strong>
    `;
}