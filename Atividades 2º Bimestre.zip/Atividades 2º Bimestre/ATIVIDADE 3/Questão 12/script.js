function decomporNumero() {
    const numero = parseInt(document.getElementById('numero').value);
    
    if (isNaN(numero) || numero < 0 || numero > 999) {
        alert("Por favor, digite um número válido entre 0 e 999!");
        return;
    }
    
    const centena = Math.floor(numero / 100);
    const dezena = Math.floor((numero % 100) / 10);
    const unidade = numero % 10;
    
    document.getElementById('centena').textContent = centena;
    document.getElementById('dezena').textContent = dezena;
    document.getElementById('unidade').textContent = unidade;
    
    document.getElementById('resultado').style.display = 'block';
}