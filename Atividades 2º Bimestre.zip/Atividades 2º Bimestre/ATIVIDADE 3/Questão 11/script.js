function calcular() {
    const salarioInicial = parseFloat(document.getElementById('salario').value);
    
    if (isNaN(salarioInicial) || salarioInicial <= 0) {
        alert("Por favor, digite um valor válido para o salário!");
        return;
    }
    
    const valorAumento = salarioInicial * 0.15;
    const salarioComAumento = salarioInicial + valorAumento;
    
    const valorImpostos = salarioComAumento * 0.08;
    const salarioFinal = salarioComAumento - valorImpostos;
    
    const formatador = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });
    
    document.getElementById('salario-inicial').textContent = formatador.format(salarioInicial);
    document.getElementById('aumento').textContent = formatador.format(valorAumento);
    document.getElementById('salario-aumento').textContent = formatador.format(salarioComAumento);
    document.getElementById('impostos').textContent = formatador.format(valorImpostos);
    document.getElementById('salario-final').textContent = formatador.format(salarioFinal);
    
    document.getElementById('resultado').style.display = 'block';
}