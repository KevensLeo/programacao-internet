function calcularDistancia() {
    const x1 = parseFloat(document.getElementById('x1').value);
    const y1 = parseFloat(document.getElementById('y1').value);
    const x2 = parseFloat(document.getElementById('x2').value);
    const y2 = parseFloat(document.getElementById('y2').value);
    
    if (isNaN(x1) || isNaN(y1) || isNaN(x2) || isNaN(y2)) {
        alert("Por favor, digite valores numéricos para todas as coordenadas!");
        return;
    }
    
    const dx = x2 - x1;
    const dy = y2 - y1;
    const distancia = Math.sqrt(dx * dx + dy * dy);
    
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        Distância entre A(${x1}, ${y1}) e B(${x2}, ${y2}):<br>
        <span class="distancia">${distancia.toFixed(2)} unidades</span>
    `;
    
    resultadoDiv.style.display = 'block';
}