function converterTempo() {
    const diasTotais = parseInt(document.getElementById('dias').value);
    
    if (isNaN(diasTotais) || diasTotais < 0) {
        alert("Por favor, digite um número válido de dias (maior ou igual a zero)!");
        return;
    }
    

    const anos = Math.floor(diasTotais / 360);
    const restoDias = diasTotais % 360;
    const meses = Math.floor(restoDias / 30);
    const dias = restoDias % 30;
    
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        <strong>${diasTotais} dias</strong> equivalem a:<br><br>
        <span class="tempo-destaque">${anos} ano(s)</span>, 
        <span class="tempo-destaque">${meses} mês(es)</span> e 
        <span class="tempo-destaque">${dias} dia(s)</span>
    `;
    
    resultadoDiv.style.display = 'block';
}