function calcularDias() {
    const dia = parseInt(document.getElementById('dia').value);
    const mes = parseInt(document.getElementById('mes').value);
    
    if (isNaN(dia)) {
        alert("Por favor, digite um dia válido!");
        return;
    }
    
    if (dia < 1 || dia > 30) {
        alert("O dia deve estar entre 1 e 30!");
        return;
    }
    
    const diasPassados = (mes - 1) * 30 + dia;
    
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        Dias passados desde o início do ano: 
        <span class="dias-destaque">${diasPassados}</span> dias
    `;
    
    resultadoDiv.style.display = 'block';
}