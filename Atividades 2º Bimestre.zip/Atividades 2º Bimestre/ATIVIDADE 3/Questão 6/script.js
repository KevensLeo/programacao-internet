function calcularValor() {
    const PRECO_POR_QUILO = 12.00;
    const pesoPrato = parseFloat(document.getElementById('peso').value);
    
    if (isNaN(pesoPrato) || pesoPrato <= 0) {
        alert("Por favor, digite um peso válido maior que zero!");
        return;
    }
    
    const valorPagar = pesoPrato * PRECO_POR_QUILO;
    
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        Valor a pagar: <span class="valor-pagar">R$ ${valorPagar.toFixed(2)}</span>
    `;
    
    resultadoDiv.style.display = 'block';
}