function calcularVendas() {
    const PRECO_PAO = 0.12;
    const PRECO_BROA = 1.50;
    const PERCENTUAL_POUPANCA = 0.10;
    
    const qtdPaes = parseInt(document.getElementById('paes').value) || 0;
    const qtdBroas = parseInt(document.getElementById('broas').value) || 0;
    
    if (qtdPaes < 0 || qtdBroas < 0) {
        alert("As quantidades não podem ser negativas!");
        return;
    }
    
    const totalPaes = qtdPaes * PRECO_PAO;
    const totalBroas = qtdBroas * PRECO_BROA;
    const totalVendas = totalPaes + totalBroas;
    const poupanca = totalVendas * PERCENTUAL_POUPANCA;
    
    const formatador = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });
    
    document.getElementById('total-vendas').textContent = formatador.format(totalVendas);
    document.getElementById('poupanca').textContent = formatador.format(poupanca);
}