function calcularFerraduras() {
    const numCavalos = parseInt(document.getElementById('cavalos').value);
    
    if (isNaN(numCavalos)) {
        alert("Por favor, digite um número válido de cavalos!");
        return;
    }
    
    if (numCavalos <= 0) {
        alert("O número de cavalos deve ser maior que zero!");
        return;
    }
    
    const ferraduras = numCavalos * 4;
    

    document.getElementById('resultado').innerHTML = `
        Para <strong>${numCavalos}</strong> cavalo(s), você precisará de <br>
        <strong>${ferraduras}</strong> ferraduras.
    `;
}