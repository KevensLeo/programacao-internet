function calcularDias() {
    const nome = document.getElementById('nome').value.trim();
    const idade = parseInt(document.getElementById('idade').value);
    
    if (nome === '') {
        alert("Por favor, digite seu nome!");
        return;
    }
    
    if (isNaN(idade) || idade < 0) {
        alert("Por favor, digite uma idade válida (número inteiro positivo)!");
        return;
    }
    
    const diasDeVida = idade * 365;
    
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        <span class="nome-destaque">${nome.toUpperCase()}</span>, VOCÊ JÁ VIVEU 
        <span class="dias-destaque">${diasDeVida.toLocaleString('pt-BR')}</span> DIAS!
    `;
    
    resultadoDiv.style.display = 'block';
}