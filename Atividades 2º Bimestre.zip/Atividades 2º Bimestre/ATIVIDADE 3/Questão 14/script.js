function dividirConta() {
    const totalConta = parseFloat(document.getElementById('conta').value);
    
    if (isNaN(totalConta) || totalConta <= 0) {
        alert("Por favor, digite um valor válido para a conta!");
        return;
    }
    
    const parteInteira = Math.floor(totalConta / 3);
    const valorCarlos = parteInteira;
    const valorAndre = parteInteira;
    
    const valorFelipe = totalConta - valorCarlos - valorAndre;
    
    const formatador = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });
    
    document.getElementById('carlos').textContent = formatador.format(valorCarlos);
    document.getElementById('andre').textContent = formatador.format(valorAndre);
    document.getElementById('felipe').textContent = formatador.format(valorFelipe);
    
    document.getElementById('resultado').style.display = 'block';
}