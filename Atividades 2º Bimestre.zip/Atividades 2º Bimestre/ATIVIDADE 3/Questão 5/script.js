function calcularLitros() {
    const precoLitro = parseFloat(document.getElementById('preco').value);
    const valorAbastecer = parseFloat(document.getElementById('valor').value);
    
    if (isNaN(precoLitro)) {
        alert("Por favor, digite um preço válido para o litro!");
        return;
    }
    
    if (isNaN(valorAbastecer)) {
        alert("Por favor, digite um valor válido para abastecer!");
        return;
    }
    
    if (precoLitro <= 0 || valorAbastecer <= 0) {
        alert("Os valores devem ser maiores que zero!");
        return;
    }
    
    const litros = valorAbastecer / precoLitro;
    

    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        Com R$ <span class="valor-destaque">${valorAbastecer.toFixed(2)}</span>, você abasteceu<br>
        <span class="valor-destaque">${litros.toFixed(3)}</span> litros de gasolina
    `;
    
    resultadoDiv.style.display = 'block';
}