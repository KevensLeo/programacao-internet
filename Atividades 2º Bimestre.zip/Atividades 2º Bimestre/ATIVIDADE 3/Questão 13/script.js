function calcularArea() {
    const PI = 3.14;
    const raio = parseFloat(document.getElementById('raio').value);
    
    if (isNaN(raio) || raio <= 0) {
        alert("Por favor, digite um raio válido maior que zero!");
        return;
    }
    
    const area = PI * Math.pow(raio, 2);
    
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `
        Área da pizza: <span class="area-destaque">${area.toFixed(2)} cm²</span>
    `;
    
    resultadoDiv.style.display = 'block';
}